# Dynamic Fraud Detection System Using Machine Learning

An educational portfolio project that trains a classifier to flag potentially fraudulent transactions and serves predictions through FastAPI.

**Data note:** This project generates synthetic data. It is not a bank-grade system and must not be used for real financial decisions.

## Features
- Generate reproducible, imbalanced synthetic transaction data
- Split train/test data before resampling
- Apply SMOTE to training data only
- Train a Random Forest classifier
- Evaluate with precision, recall, F1, confusion matrix and ROC-AUC
- Serve predictions through FastAPI

## Setup
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Generate data and train
```bash
python generate_data.py
python train_model.py
```

The generated CSV is saved to `data/transactions.csv`; the trained pipeline is saved to `models/fraud_detection_pipeline.joblib`. Generated data and model binaries are excluded from Git by `.gitignore`.

## Run the API
```bash
uvicorn app:app --reload
```
Open `http://127.0.0.1:8000/docs`.

Example `POST /predict` JSON:
```json
{
  "amount": 850.0,
  "hour": 2,
  "distance_from_home_km": 120.0,
  "transactions_last_24h": 8,
  "merchant_risk_score": 0.9
}
```

## Features
| Feature | Meaning |
|---|---|
| amount | Synthetic transaction amount |
| hour | Hour of day (0–23) |
| distance_from_home_km | Distance from usual location |
| transactions_last_24h | Recent transaction count |
| merchant_risk_score | Synthetic risk score (0–1) |
| is_fraud | Target: 1 synthetic fraud, 0 legitimate |

## Limitations
Synthetic data is illustrative and does not represent real financial behaviour. Metrics on this data do not establish real-world performance. A real deployment would require a licensed real dataset, robust validation, threshold tuning, monitoring, security and domain review.

## Author
**Sandasani Karthik** — B.E. Artificial Intelligence and Machine Learning
